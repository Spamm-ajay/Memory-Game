const cardImages = [
    'kung-fu-panda-cartoon-clipart.webp', 'kung-fu-panda-cartoon-clipart.webp',
    'snow white.png', 'snow white.png',
    'Dragon.png', 'Dragon.png',
    'tiger.png.webp', 'tiger.png.webp',
    'a.webp', 'a.webp',
    'elephant.png', 'elephant.png',
    'ben10.png', 'ben10.png',
    'panda.png', 'panda.png'
]; // this is array for store card images

let firstCard, secondCard; // this are use for flip images store for checking matches
let score = 0; // score initialization is zero
let matchedCards = 0; // matches card initialization is zero
let timer; // this variable use for hold the time when all pairs are match
let timeElapsed = 0; // this is use for time calculate by second

function shuffle(array) { //this is function of shuffle(array)
    for (let i = array.length - 1; i > 0; i--) { //here use for loop for shuffle the cards that start from length-1
        const j = Math.floor(Math.random() * (i + 1)); // math.random() are use to produces floating point numbers between 0 and 1
        // math.floor are use for convert float to integer
        [array[i], array[j]] = [array[j], array[i]]; // this line swaps the elements at indices i and j in array
    }
    return array; //this function returns the shuffle array elements
}
// Function for create a game board and display game board for card game
function createGameBoard() {
    const board = document.getElementById('game-board'); // this selects the HTMl element with id game-board and stored in board variable
    board.innerHTML = ''; // use to clears existing content inside board element every time when function called the game board start fresh
    const shuffledCards = shuffle([...cardImages]); // this creates shuffled version of an array called card images
    // create and append card elements for each image
    shuffledCards.forEach(image => {
        //create a card element
        const card = document.createElement('div'); // inside the loop this create new div for back element card and stores it
        // assign a class name allowing for css styling and javascript manipulation based on class
        card.className = 'card';
        card.dataset.image = image; // this sets a custom data attribute data-image on div data attribute holds the value of current img
        card.innerHTML = `<img src="${image}" alt="Cartoon Character">`; // adds <img> element inside div card and display corresponding img
        card.addEventListener('click', flipCard); // attach a click event listener to card when card clicked function flip card will be called.
        board.appendChild(card); // appends the newly created card and adds the card to the display making it visible on the game board.
    });
}

// create a function for flip card when click on card
function flipCard() {
    if (firstCard && secondCard) return; // the function immediately returns

    this.classList.add('flipped'); // this adds a class named flipped to the card that was clicked.

    if (!firstCard) { // this checks no card has been flipped before
        firstCard = this; // this indicates that the first card has been selected and flipped.
    } else {
        secondCard = this; // this assign the current card into second card.
        checkForMatch(); // here we called the function for flipped cards check for match.
    }
}

// create a function for check two flipped cards are matches or not
function checkForMatch() {
    if (firstCard.dataset.image === secondCard.dataset.image) { // here we use strict equality operator for check two img are equal or not
        score++; // when two img are same then score increment by 1
        matchedCards += 2; // here we use compound assignment operator for assign value two in variable of matched cards.
        updateScore(); /// here we called the function for update score

        firstCard.classList.add('matched'); // these are use for two cards have been successfully matched.
        secondCard.classList.add('matched');

        resetCards(); // here we called reset cards function. for player can flip new cards.

        if (matchedCards === cardImages.length) { // this block checks if total number of matched cards equal the total number of cards in the game.
            endGame(); // if condition true then start end game function.
        }
    } else {
        setTimeout(() => { // here we create else condition for timeout
            firstCard.classList.remove('flipped');
            secondCard.classList.remove('flipped');
            resetCards();
        }, 1000); // after completing 1000 milliseconds card will be reset.
    }
}
// create function for reset cards.
function resetCards() {
    firstCard = null; // using assignment operator give the null value to first card and second card.
    secondCard = null;
}

function updateScore() {
    document.getElementById('score').textContent = score; // this is use for update score dynamically as they progress.
}

// create a function for start timer
function startTimer() {
    timer = setInterval(() => { // this is use setInterval for create a repeating timer.
        timeElapsed++; // this is increments the time elapsed variable bye 1 every second  it use for tracks the total time that passed since the timer started.
        document.getElementById('timer').textContent = formatTime(timeElapsed); // this use for updates the displayed timer in the html.
    }, 1000);
}
// create a format time function with the passing seconds parameter.
function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60); // this use for calculates the total number of whole minutes from the total sec
    const secs = seconds % 60; //  It gives remainder of seconds divided by 60
    return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
} // it converts minutes to a string and pads it with leading zeros if it only has one digit

// create a function for end the game
function endGame() {
    clearInterval(timer); // this is built-in javascript function that set with setInterval
    alert(`Congratulations..! Your score: ${score}, Time taken: ${formatTime(timeElapsed)}`); // here show the winning comment after win the game using alert
}

// create a function for restart the game
function restartGame() {
    clearInterval(timer); // this function clear the timer and start from zero
    score = 0; // score will be zero.
    matchedCards = 0; //matched cards will be zero.
    timeElapsed = 0; // time elapsed will be zero.
    updateScore(); // call the update score function
    document.getElementById('timer').textContent = '00:00'; // this is use to find html element with the id timer and sets displayed text to 00:00.
    createGameBoard(); // call the create board function
    startTimer(); // called function start timer for start time at zero.
}

// Event listeners this is use for click on restart game button.
document.getElementById('restart').addEventListener('click', restartGame);

// Start the game
restartGame();